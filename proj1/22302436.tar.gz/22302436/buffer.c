
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {
    char *data;
    int size;
    int capacity;
} Buffer;

void bufInit(Buffer *buf) {
    buf->size = 0;
    buf->capacity = 1;
    buf->data = (char *)malloc(1 * sizeof(char));
    if (!buf->data) {
        fprintf(stderr, "Error: Couldn't initialize buffer");
        exit(1);
    }
}

void bufAppend(Buffer *buf, char c) {
    // Grow if at capacity
    if (buf->size == buf->capacity) {
        int newCapacity = buf->capacity * 2;
        char *newAddress =
            (char *)realloc(buf->data, newCapacity * sizeof(char));
        if (!newAddress) {
            fprintf(stderr, "Error: Couldn't expand buffer");
            exit(1);
        }
        buf->data = newAddress;
        buf->capacity = newCapacity;
    }
    int idx = buf->size;
    buf->data[idx] = c;
    buf->size++;
}

void bufFree(Buffer *buf) {
    free(buf->data);
    buf->data = NULL;
    buf->size = 0;
    buf->capacity = 0;
}

typedef struct {
    char *word;
    int fileNo;
    int lineNo;
} WordOccurance;

typedef struct {
    WordOccurance *data;
    int size;
    int capacity;
} WordList;

void listInit(WordList *list) {
    list->size = 0;
    list->capacity = 1;
    list->data = (WordOccurance *)malloc(1 * sizeof(WordOccurance));
    if (!list->data) {
        fprintf(stderr, "Error: Couldn't initialize list");
        exit(1);
    }
}

void listAppend(WordList *list, char *word, int fileNo, int lineNo) {
    // Grow if at capacity
    if (list->size == list->capacity) {
        int newCapacity = list->capacity * 2;
        WordOccurance *newAddress = (WordOccurance *)realloc(
            list->data, newCapacity * sizeof(WordOccurance));
        if (!newAddress) {
            fprintf(stderr, "Error: Couldn't expand list");
            exit(1);
        }
        list->data = newAddress;
        list->capacity = newCapacity;
    }

    // Create the word occurance
    WordOccurance occurance;
    occurance.fileNo = fileNo;
    occurance.lineNo = lineNo;
    occurance.word = (char *)malloc(strlen(word) + 1);
    strcpy(occurance.word, word);

    int idx = list->size;
    list->data[idx] = occurance;
    list->size++;
}

void listFree(WordList *list) {
    for (int i = 0; i < list->size; i++) {
        free(list->data[i].word);
    }
    free(list->data);
    list->data = NULL;
    list->size = 0;
    list->capacity = 0;
}

static int cmpWordOccurance(const void *a, const void *b) {
    WordOccurance *wordA = (WordOccurance *)a;
    WordOccurance *wordB = (WordOccurance *)b;
    // Sort by word, then file, then line
    int res = strcmp(wordA->word, wordB->word);
    if (res != 0) {
        return res;
    }
    // Words are the same, check file
    if (wordA->fileNo < wordB->fileNo) {
        return -1;
    } else if (wordA->fileNo > wordB->fileNo) {
        return 1;
    }
    // Files are the same, check line
    // What about multiple words on the same line
    if (wordA->lineNo < wordB->lineNo) {
        return -1;
    } else if (wordA->lineNo > wordB->lineNo) {
        return 1;
    }
    // Completely equal
    return 0;
}

void listSort(WordList *list) {
    qsort(list->data, list->size, sizeof(WordOccurance), cmpWordOccurance);
}
